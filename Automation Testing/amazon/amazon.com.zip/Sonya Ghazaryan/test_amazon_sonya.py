from selenium import webdriver
from selenium.webdriver.common.by import By
from webdriver_manager.microsoft import EdgeChromiumDriverManager

def test_amazon():
    driver = webdriver.Edge(executable_path=EdgeChromiumDriverManager().install())
    driver.maximize_window()
    driver.get('https://www.amazon.com/')
    driver.find_element(By.ID,'twotabsearchtextbox').send_keys('iphone')
    driver.find_element(By.ID,'nav-search-submit-button').click()
    assert driver.find_element(By.XPATH, '//div[@data-component-type="s-search-result"]'), 'The search has no result'
    driver.close()